(function($) {
    
    // Switch
    $("#moo-ui-switch-1").ui({
        type: "Switch",
        value: 0
    });
    
    // Text
    $("#moo-ui-text-1").ui({
        type: "Text"
    });
    
    // TextArea
    $("#moo-ui-textarea-1").ui({
        type: "TextArea"
    });
    
    // Select
    $("#moo-ui-select-1").ui({
        type: "Select",
        position: "bottom"
    });
        
    // Radio
    $("#moo-ui-radio-1").ui({
        type: "Radio",
    });
    
    // Checkbox
    $("#moo-ui-checkbox-1").ui({
        type: "Checkbox",
    });
    
}(Mootor));
