(function($) {

    // Code here

}(Mootor));
