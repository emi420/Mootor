(function($) {

    // Code here

}(Mootor));
// Code here