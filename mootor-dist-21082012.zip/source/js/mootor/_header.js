/**
 * Mootor - HTML5 library for application development
 * 
 * You may use any Mootor project under the terms of either the MIT License
 * or the GNU General Public License (GPL) Version 3.
 * 
 * (c) 2012 Emilio Mariscal (emi420 [at] gmail.com)
 *
 */

(function (document) {

"use strict";

