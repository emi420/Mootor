/**
 * @summary User Interface Mootor plugin
 * @author Emilio Mariscal (emi420 [at] gmail.com)
 */
 
/** 
 * @class
 * @name $ 
 */
 
(function ($) {

    "use strict";