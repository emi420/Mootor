// #include "nav.js"

/**
 * Footer
 * @param {object} self Nav instance
 * @return {object} Footer Footer instance
 */
var Footer = function(self) {        
    // TODO: create an object like Header
    //       ex: using a NavBar constructor
};

