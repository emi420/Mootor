}(Mootor));
