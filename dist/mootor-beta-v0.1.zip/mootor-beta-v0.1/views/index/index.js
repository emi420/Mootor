(function ($) {

    "use strict";
    
    m.app.view("index").on("load", function() {
        // code here
    });
    
}(window.$));